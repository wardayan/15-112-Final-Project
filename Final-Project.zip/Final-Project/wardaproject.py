#    15-112: Principles of Programming and Computer Science
#    HW07 Programming: Final Project - Maze
#    Name      : Ward Ayan
#    AndrewID  : warda

#    File Created: 11/10/2017
#    Modification History:
#    Start:                 End:
#    11/10    5:45pm        11/11    1:00am
#    11/11    4:00pm        11/11    8:00pm
#    11/12    5:30pm        11/12    11:30pm

from Tkinter import *
from random import *

class HomePage():
    def __init__(self, parent, mazes):
        self.parent = parent
        self.mazes = mazes
        wnd.title('The Amazing Maze')
        self.canvas = Canvas(self.parent, height = 700, width = 700)
        self.canvas.pack()

        self.canvas.create_image(350, 350, image = homePageBg)

        self.instructions = Button(self.canvas, text = 'Instructions', height = 3, width = 30, bg = 'white', command = self.openInstructions)
        self.canvas.create_window(500, 350, window = self.instructions)

        self.onep = Button(self.canvas, text = 'One Player Game', height = 3, width = 30, bg = 'white', command = self.openOnePlayer)
        self.canvas.create_window(500, 420, window = self.onep)

        self.twop = Button(self.canvas, text = 'Two Player Game', height = 3, width = 30, bg = 'white', command = self.openTwoPlayer)
        self.canvas.create_window(500, 490, window = self.twop)

        self.score = Button(self.canvas, text = 'Scoreboard', height = 3, width = 30, bg = 'white', command = self.openScore)
        self.canvas.create_window(500, 560, window = self.score)

        self.load = Button(self.canvas, text = 'Load Game', height = 3, width = 30, bg = 'white')
        self.canvas.create_window(500, 630, window = self.load)

    def openInstructions(self):
        self.canvas.destroy()
        InstructionsWindow(self.parent)

    def openScore(self):
        self.canvas.destroy()
        ScoreboardWindow(self.parent)

    def openOnePlayer(self):
        Maze(self.parent, 1, self.mazes)

    def openTwoPlayer(self):
        Maze(self.parent, 2, self.mazes)
        

class InstructionsWindow():
    def __init__(self, parent):
        self.parentI = parent
        self.canvasI = Canvas(self.parentI, height = 700, width = 700)
        self.canvasI.pack()

        self.canvasI.create_image(350, 370, image = InstructionsPage)
        
        self.back = Button(self.canvasI, text = 'Back', height = 3, width = 30, bg = 'white', command = self.backButton)
        self.canvasI.create_window(350, 630, window = self.back)

    def backButton(self):
        self.canvasI.destroy()
        HomePage(self.parentI, mazes)


class ScoreboardWindow():
    def __init__(self, parent):
        self.parentS = parent
        self.canvasS = Canvas(self.parentS, height = 700, width = 700)
        self.canvasS.pack()

        self.canvasS.create_image(350, 370, image = Scoreboardpage)

        self.home = Button(self.canvasS, text = 'Home Page', height = 3, width = 30, bg = 'white', command = self.homeButton)
        self.canvasS.create_window(350, 630, window = self.home)

    def homeButton(self):
        self.canvasS.destroy()
        HomePage(self.parentS, mazes)


class Maze():
    def __init__(self, parent, players, mazes):
        self.parentM1 = parent
        self.mazes = mazes
        
        if players == 1:
            self.window = Toplevel()
            self.window.title('The Amazing Maze')
            self.window.geometry('700x700')
            self.window.resizable(width = False, height = False)

            self.frame1 = Frame(self.window, height = 50, width = 700, bg = 'black')
            self.frame1.pack()
            self.frame1.pack_propagate(0)

            self.heartpic = Label(self.frame1, image = Heart, bg = 'black', height = 50, width = 50)
            self.heartpic.pack(side = 'left')
            self.hearts = 3
            self.heartcounter = Label(self.frame1, text = self.hearts, foreground = 'white', bg = 'black', justify = 'left')
            self.heartcounter.pack(side = 'left')

            self.coinpic = Label(self.frame1, image = Coin, bg = 'black', height = 50, width = 50)
            self.coinpic.pack(side = 'left')
            self.coins = 0
            self.coincounter = Label(self.frame1, text = self.coins, foreground = 'white', bg = 'black', justify = 'left')
            self.coincounter.pack(side = 'left')
            
            self.frame2 = Frame(self.window, height = 650, width = 700, bg = 'black')
            self.frame2.pack(side = 'bottom')
            self.canvasO = Canvas(self.frame2, height = 650, width = 700, bg = 'black')
            self.canvasO.pack(side = 'bottom')
            
            self.theMaze = choice(self.mazes)
             
            self.character = Player
            self.x = 185
            self.y = 160

            self.redraw()
            self.parentM1.bind('<Key>', self.keyPressed)

        elif players == 2:
            self.window = Toplevel()
            self.window.title('The Amazing Maze')
            self.window.geometry('1400x700')
            self.window.resizable(width = False, height = False)

            self.FirstMaze = choice(self.mazes)
            self.SecondMaze = choice(self.mazes)

            self.frame1 = Frame(self.window, height = 50, width = 1400, bg = 'black')
            self.frame1.pack(side = 'top')
            self.frame1.pack_propagate(0)

            self.frame2 = Frame(self.window, height = 650, width = 700, bg = 'black')
            self.frame2.pack(side = 'left')
            self.canvasO1 = Canvas(self.frame2, height = 650, width = 700, bg = 'black')
            self.canvasO1.pack(side = 'bottom')

            self.frame3 = Frame(self.window, height = 650, width = 700, bg = 'black')
            self.frame3.pack(side = 'bottom')
            self.canvasO2 = Canvas(self.frame3, height = 650, width = 700, bg = 'black')
            self.canvasO2.pack(side = 'bottom')

            self.canvasO1.create_image(350, 325, image =self.FirstMaze)
            self.canvasO2.create_image(350, 325, image = self.SecondMaze)
            
                    
    def keyPressed(self, event):
        if event.keysym == 'Up':
            if self.y + 10 >= 172:
                self.y -= 10
                self.redraw()

        if event.keysym == 'Down':
            if self.y + 10 <= 490:
                self.y += 10
                self.redraw()

        if event.keysym == 'Right':
            if self.x + 10 <= 516:
                self.x += 10
                self.redraw()

        if event.keysym == 'Left':
            if self.x + 10 >= 200:
                self.x -= 10
                self.redraw()

    def redraw(self):
        self.canvasO.delete(ALL)
        self.canvasO.create_image(350, 325, image = self.theMaze)
        self.canvasO.create_image(self.x, self.y, image = self.character)
        
            

wnd = Tk()

Maze1 = PhotoImage(file = 'maze1.gif')
Maze2 = PhotoImage(file = 'maze2.gif')
mazes = [Maze1, Maze2]

homePageBg = PhotoImage(file = 'MAZE.gif')
InstructionsPage = PhotoImage(file = 'InstructionsPage.gif')
Scoreboardpage = PhotoImage(file = 'Scoreboard.gif')
Heart = PhotoImage(file = 'heart.gif')
Coin = PhotoImage(file = 'coin.gif')
Player = PhotoImage(file = 'char.gif')

wnd.geometry('700x700')
wnd.resizable(width = False, height = False)
game = HomePage(wnd, mazes)
wnd.mainloop()
