#    15-112: Principles of Programming and Computer Science
#    HW07 Programming: Final Project - Maze
#    Name      : Ward Ayan
#    AndrewID  : warda

#    File Created: 11/10/2017
#    Modification History:
#    Start:                 End:
#    11/10    5:45pm        11/11    1:00am
#    11/11    4:00pm        11/11    8:00pm
#    11/12    5:30pm        11/12    11:30pm
#    11/24    6:00pm        11/24    10:00pm
#    11/25    11:00pm       11/26    7:30am
#    11/26    6:00pm        11/27    1:00am

from Tkinter import *
from random import *
import time

class HomePage():
    #this class creates the window that leads to everywhere else in the game.

    def __init__(self, parent, mazes):
        #lay out is creates on a canvas
        self.parent = parent
        self.mazes = mazes
        wnd.title('The Amazing Maze')
        self.canvas = Canvas(self.parent, height = 700, width = 700)
        self.canvas.pack()

        self.canvas.create_image(350, 350, image = homePageBg)

        #buttins that lead to one player, two player, instructions, scoreboeard and option to load a saved game
        self.instructions = Button(self.canvas, text = 'Instructions', height = 3, width = 30, bg = 'white', command = self.openInstructions)
        self.canvas.create_window(500, 350, window = self.instructions)

        self.onep = Button(self.canvas, text = 'One Player Game', height = 3, width = 30, bg = 'white', command = self.openOnePlayer)
        self.canvas.create_window(500, 420, window = self.onep)

        self.twop = Button(self.canvas, text = 'Two Player Game', height = 3, width = 30, bg = 'white', command = self.openTwoPlayer)
        self.canvas.create_window(500, 490, window = self.twop)

        self.score = Button(self.canvas, text = 'Scoreboard', height = 3, width = 30, bg = 'white', command = self.openScore)
        self.canvas.create_window(500, 560, window = self.score)

        self.load = Button(self.canvas, text = 'Load Game', height = 3, width = 30, bg = 'white', command = self.openLoad)
        self.canvas.create_window(500, 630, window = self.load)

    def openInstructions(self):
        #command function for the instructions window
        self.canvas.destroy()
        InstructionsWindow(self.parent)

    def openScore(self):
        #command function for the scoreboard window
        self.canvas.destroy()
        ScoreboardWindow(self.parent)

    def openOnePlayer(self):
        #command function for the one player game
        Maze(self.parent, 1, self.mazes)

    def openTwoPlayer(self):
        #comman function for the two player game
        Maze(self.parent, 2, self.mazes)

    def openLoad(self):
        #command function for the Load game option
        #read the file that contains the number of games the player has to complete
        f = open('levels.txt', 'r')
        levels1 = f.readline()

        #if the file is empty then there is nothing to load
        if levels1 == '':
            self.M = Toplevel()
            self.M1 = Label(self.M, text = 'Sorry, there is not saved game to load')
            self.M1.pack()
        #if the file isn't empty then the info (levels, hearts, coins) and calls the class Maze with this info
        else:
            levels1 = int(levels1)
            hearts1 = int(f.readline())
            coins1 = int(f.readline())
            f.close()
            f = open('levels.txt', 'w')
            #after the game is loaded, the info is erased 
            f.seek(0)
            f.truncate()
            f.close()
            Maze(self.parent, 1, self.mazes, levels = levels1, hearts = hearts1, coins = coins1)
        

class InstructionsWindow():
    #Instructions window display
    def __init__(self, parent):
        self.parentI = parent
        self.canvasI = Canvas(self.parentI, height = 700, width = 700)
        self.canvasI.pack()

        self.canvasI.create_image(350, 370, image = InstructionsPage)
        
        self.back = Button(self.canvasI, text = 'Back', height = 3, width = 30, bg = 'white', command = self.backButton)
        self.canvasI.create_window(350, 630, window = self.back)

    def backButton(self):
        #function for the back button
        self.canvasI.destroy()
        HomePage(self.parentI, mazes)


class ScoreboardWindow():
    def __init__(self, parent):
        #display of the HighScore window
        self.parentS = parent
        self.canvasS = Canvas(self.parentS, height = 700, width = 700)
        self.canvasS.pack()

        self.canvasS.create_image(350, 370, image = Scoreboardpage)

        self.home = Button(self.canvasS, text = 'Home Page', height = 3, width = 30, bg = 'white', command = self.homeButton)
        self.canvasS.create_window(350, 630, window = self.home)

        #open file that contains HS, if empty add HS, if not compare points if current is larger then change else, don't
        f = open('highscore.txt', 'r')
        self.contentforHS = f.readline()

        if self.contentforHS == '':
            self.texttoshow = 'No Highscore Yet'
            self.HSlabel = Label(self.canvasS, text = self.texttoshow, fg = 'white', bg = 'black')
            self.HSdisplay = self.canvasS.create_window(200, 350, window = self.HSlabel)
            
        else:
            self.seperated = self.contentforHS.split()
            self.usertxt = self.seperated[0]
            self.coinsnumber = self.seperated[1]
            self.texttoshow = 'Username: '+ self.usertxt + '      Coins: ' + self.coinsnumber

            self.HSlabel = Label(self.canvasS, text = self.texttoshow, fg = 'white', bg = 'black')
            self.HSdisplay = self.canvasS.create_window(200, 350, window = self.HSlabel)

        f.close()

    def homeButton(self):
        #function for back button
        self.canvasS.destroy()
        HomePage(self.parentS, mazes)


class Maze():
    def __init__(self, parent, players, mazes, levels = 3, hearts = 3, coins = 0):
        #this class takes care of both the one player and the two player games.
        #we have here the different locations that the elements appearing on the maze can have
        #the speeds of the characters
        #the directions of the bad guys
        self.parentM = parent
        self.mazes = mazes
        self.velocities = [0, 0, 0, 0]
        self.velocities1 = [0, 0, 0, 0]
        self.velocities2 = [0, 0, 0, 0]
        self.badlocations = [(180, 480), (510, 169), (350, 325), (400, 485), (350, 485), (510, 325), (400, 480)]
        self.baddirections = ['UP', 'DOWN', 'LEFT', 'RIGHT']
        self.heartlocations = [(190, 480), (510, 169), (350, 325), (400, 485), (350, 485), (510, 325), (400, 480)]
        self.coinlocations = [(190, 480), (510, 169), (350, 325), (400, 485), (350, 485), (510, 325), (400, 480)]
 
        #coordinated of the characters (1 and 2 player)
        self.x = 185
        self.y = 160
        self.x1 = 185
        self.y1 = 160
        self.x2 = 885
        self.y2 = 160
            
        if players == 1:
            #if it's a one player game
            self.window = Toplevel()
            self.window.bind('<Button-1>', self.mousepressed)
            self.window.title('The Amazing Maze')
            self.window.geometry('700x700')
            self.window.resizable(width = False, height = False)

            #frame that contains the heart and coin counter that is updates after every collision with one of these
            self.frame1 = Frame(self.window, height = 50, width = 700, bg = 'black')
            self.frame1.pack()
            self.frame1.pack_propagate(0)

            self.heartpic = Label(self.frame1, image = Heart, bg = 'black', height = 50, width = 50)
            self.heartpic.pack(side = 'left')
            self.hearts = hearts
            self.heartcounter = Label(self.frame1, text = self.hearts, foreground = 'white', bg = 'black', justify = 'left')
            self.heartcounter.pack(side = 'left')

            self.coinpic = Label(self.frame1, image = Coin, bg = 'black', height = 50, width = 50)
            self.coinpic.pack(side = 'left')
            self.coins = coins
            self.coincounter = Label(self.frame1, text = self.coins, foreground = 'white', bg = 'black', justify = 'left')
            self.coincounter.pack(side = 'left')
            
            #frame that contains the maze and the characters
            self.frame2 = Frame(self.window, height = 650, width = 700, bg = 'black')
            self.frame2.pack(side = 'bottom')
            self.canvasO = Canvas(self.frame2, height = 650, width = 700, bg = 'black')
            self.canvasO.pack(side = 'bottom')
            
            #the maze is chosen at random from all the mazes downloaded
            self.theMaze = choice(self.mazes)
            self.canvasO.create_image(350, 325, image = self.theMaze)

            #the first bad guy is placed at random from the different possible locations
            self.location1 = choice(self.badlocations)
            self.badx1 = self.location1[0]
            self.bady1 = self.location1[1]
            self.move1 = choice(self.baddirections)
            self.bad1 = self.canvasO.create_oval(self.badx1 - 6, self.bady1 - 6, self.badx1 + 6, self.bady1 + 6, fill = 'yellow')
            self.collisionbad1 = False

            #the second bad guy is placed at random from the different possible locations
            self.location2 = choice(self.badlocations)
            self.badx2 = self.location2[0]
            self.bady2 = self.location2[1]
            self.move2 = choice(self.baddirections)
            self.bad2 = self.canvasO.create_oval(self.badx2 - 6, self.bady2 - 6, self.badx2 + 6, self.bady2 + 6, fill = 'yellow')
            self.collisionbad2 = False

            #the third bad guy is placed at random from the different possible locations
            self.location3 = choice(self.badlocations)
            self.badx3 = self.location3[0]
            self.bady3 = self.location3[1]
            self.move3 = choice(self.baddirections)
            self.bad3 = self.canvasO.create_oval(self.badx3 - 6, self.bady3 - 6, self.badx3 + 6, self.bady3 + 6, fill = 'yellow')
            self.collisionbad3 = False

            #the coin is placed at random 
            self.coinlocation = choice(self.coinlocations)
            self.coin = self.canvasO.create_image(self.coinlocation[0], self.coinlocation[1], image = Coin)
            self.coincollision = False

            #the heart is placed at random
            self.heartlocation = choice(self.heartlocations)
            self.heart = self.canvasO.create_image(self.heartlocation[0], self.heartlocation[1], image = Heart)
            self.heartcollision = False

            #the number of level left that the player needs to complete, default is three unless specified otherwise when calling the class
            self.levelsleft = levels
            self.gameover = False

            #place the player at the top of the maze
            self.player = self.canvasO.create_oval(self.x - 10, self.y - 10, self.x + 10, self.y + 10, fill = 'black')

            self.timer1()

            #bind the window to keys pressed to move the characters
            self.parentM.bind('<Key>', self.keyPressed1)

        elif players == 2:
            #2 player window display
            self.window = Toplevel()
            self.window.bind('<Button-1>', self.mousepressed)
            self.window.title('The Amazing Maze')
            self.window.geometry('1400x650')
            self.window.resizable(width = False, height = False)

            #the 2 displayed mazes are chosen at random
            self.FirstMaze = choice(self.mazes)
            self.SecondMaze = choice(self.mazes)

            self.frame1 = Frame(self.window, height = 650, width = 700, bg = 'black')
            self.frame1.pack(side = 'left')
            self.canvasO1 = Canvas(self.frame1, height = 650, width = 1400, bg = 'black')
            self.canvasO1.pack(side = 'bottom')

            self.canvasO1.create_image(350, 325, image = self.FirstMaze)
            self.canvasO1.create_image(1050, 325, image = self.SecondMaze)

            self.player1 = self.canvasO1.create_oval(self.x1 - 10, self.y1 - 10, self.x1 + 10, self.y1 + 10, fill = 'blue', outline = 'blue')
            self.player2 = self.canvasO1.create_oval(self.x2 - 10, self.y2 - 10, self.x2 + 10, self.y2 + 10, fill = 'red', outline = 'red')

            self.timer2()
            self.parentM.bind('<Key>', self.keyPressed2)

    def MoveBaddie(self):
        #this function takes care of the random movement of the bad guys, if the pixel in its chosen direction is black then chose another direction
        #if not then make the bad guy move forward by one pixel.
        if self.move1 == 'UP' and self.bady1 >= 162 and self.theMaze.get(self.badx1 - 172, self.bady1 - 6 - 146) == '255 255 255':
            self.bady1 -= 1
        elif self.move1 == 'DOWN' and self.bady1 <= 492 and self.theMaze.get(self.badx1 - 172, self.bady1 + 6 - 146) == '255 255 255':
            self.bady1 += 1
        elif self.move1 == 'LEFT' and self.badx1 >= 185 and self.theMaze.get(self.badx1 - 6 - 172, self.bady1 - 146) == '255 255 255':
            self.badx1 -= 1
        elif self.move1 == 'RIGHT' and self.badx1 <= 516 and self.theMaze.get(self.badx1 + 6 - 172, self.bady1 - 146) == '255 255 255':
            self.badx1 += 1
        else:
            self.move1 = choice(self.baddirections)


        if self.move2 == 'UP' and self.bady2 >= 162 and self.theMaze.get(self.badx2 - 172, self.bady2 - 6 - 146) == '255 255 255':
            self.bady2 -= 1
        elif self.move2 == 'DOWN' and self.bady2 <= 492 and self.theMaze.get(self.badx2 - 172, self.bady2 + 6 - 146) == '255 255 255':
            self.bady2 += 1
        elif self.move2 == 'LEFT' and self.badx2 >= 185 and self.theMaze.get(self.badx2 - 6 - 172, self.bady2 - 146) == '255 255 255':
            self.badx2 -= 1
        elif self.move2 == 'RIGHT' and self.badx2 <= 516 and self.theMaze.get(self.badx2 + 6 - 172, self.bady2 - 146) == '255 255 255':
            self.badx2 += 1
        else:
            self.move2 = choice(self.baddirections)


        if self.move3 == 'UP' and self.bady3 >= 162 and self.theMaze.get(self.badx3 - 172, self.bady3 - 6 - 146) == '255 255 255':
            self.bady3 -= 1
        elif self.move3 == 'DOWN' and self.bady3 <= 492 and self.theMaze.get(self.badx3 - 172, self.bady3 + 6 - 146) == '255 255 255':
            self.bady3 += 1
        elif self.move3 == 'LEFT' and self.badx3 >= 185 and self.theMaze.get(self.badx3 - 6 - 172, self.bady3 - 146) == '255 255 255':
            self.badx3 -= 1
        elif self.move3 == 'RIGHT' and self.badx3 <= 516 and self.theMaze.get(self.badx3 + 6 - 172, self.bady3 - 146) == '255 255 255':
            self.badx3 += 1
        else:
            self.move3 = choice(self.baddirections)
                
    def keyPressed1(self, event):
        #this function takes care of the character's movement for the one player game.
        #makes the speed of the character 0 when a key is pressed.
        self.velocities = [0, 0, 0, 0]

        #checks the direction of the character, if the pixel that wants to be reached is within the boundaries of the maze
        #and if the pixel is white (accessible)
        if event.keysym == 'Up':
            if self.y + 1 >= 162:
                if self.theMaze.get(self.x - 172, self.y - 11 - 146) == '255 255 255':
                    self.velocities[0] = -1

        if event.keysym == 'Down':
            if self.y + 1 <= 492:
                if self.theMaze.get(self.x - 172, self.y + 11 - 146) == '255 255 255':
                    self.velocities[1] = 1

        if event.keysym == 'Right':
            if self.x + 1 <= 516:
                if self.theMaze.get(self.x + 11 - 169, self.y - 146) == '255 255 255':
                    self.velocities[2] = 1

        if event.keysym == 'Left':
            if self.x + 1 >= 185:
                if self.theMaze.get(self.x - 11 - 171, self.y - 146) == '255 255 255':
                    self.velocities[3] = -1                 

    def keyPressed2(self, event):
        #this function takes care of the character's movement for the one player game.
        #makes the speeds 0 fro each individual key so that one character's movement
        #doesn't conflict with the other's
        if event.char == 'w':
            self.velocities1 = [0, 0, 0, 0]
            if self.y1 + 1 >= 162:
                if self.FirstMaze.get(self.x1 - 172, self.y1 - 11 - 146) == '255 255 255':
                    self.velocities1[0] = -1

        if event.char == 's':
            self.velocities1 = [0, 0, 0, 0]
            if self.y1 + 1 <= 492:
                if self.FirstMaze.get(self.x1 - 172, self.y1 + 11 - 146) == '255 255 255':
                    self.velocities1[1] = 1

        if event.char == 'd':
            self.velocities1 = [0, 0, 0, 0]
            if self.x1 + 1 <= 516:
                if self.FirstMaze.get(self.x1 + 11 - 169, self.y1 - 146) == '255 255 255':
                    self.velocities1[2] = 1

        if event.char == 'a':
            self.velocities1 = [0, 0, 0, 0]
            if self.x1 + 1 >= 185:
                if self.FirstMaze.get(self.x1 - 11 - 171, self.y1 - 146) == '255 255 255':
                    self.velocities1[3] = -1


                    
        if event.keysym == 'Up':
            self.velocities2 = [0, 0, 0, 0]
            if self.y2 + 1 >= 162:
                if self.SecondMaze.get(self.x2 - 872, self.y2 - 11 - 146) == '255 255 255':
                    self.velocities2[0] = -1

        if event.keysym == 'Down':
            self.velocities2 = [0, 0, 0, 0]
            if self.y2 + 1 <= 492:
                if self.SecondMaze.get(self.x2 - 872, self.y2 + 11 - 146) == '255 255 255':
                    self.velocities2[1] = 1

        if event.keysym == 'Right':
            self.velocities2 = [0, 0, 0, 0]
            if self.x2 + 1 <= 1216:
                if self.SecondMaze.get(self.x2 + 11 - 869, self.y2 - 146) == '255 255 255':
                    self.velocities2[2] = 1

        if event.keysym == 'Left':
            self.velocities2 = [0, 0, 0, 0]
            if self.x2 + 1 >= 885:
                if self.SecondMaze.get(self.x2 - 11 - 871, self.y2 - 146) == '255 255 255':
                    self.velocities2[3] = -1
                    

    def redraw1(self):
        #this function is called based on a certain amount of time that passes.
        #it checks for any change to the coordinates of the characters on screen and applies them
        self.canvasO.delete(self.player, self.bad1, self.bad2, self.bad3, self.heart, self.coin)
        self.player = self.canvasO.create_oval(self.x - 10, self.y - 10, self.x + 10, self.y + 10, fill = 'black')

        #it checks for collision with badguys and changes the heart counter accordingly
        if (self.x <= self.badx1 + 16 and self.x >= self.badx1 - 16 and self.y <= self.bady1 + 16 and self.y >= self.bady1 - 16) and self.collisionbad1 == False:
            self.canvasO.delete(self.bad1)
            self.collisionbad1 = True
            self.hearts -= 1
            self.heartcounter.destroy()
            self.heartcounter = Label(self.frame1, text = self.hearts, foreground = 'white', bg = 'black', justify = 'left')
            self.heartcounter.pack(side = 'left')
            self.coinpic.destroy()
            self.coincounter.destroy()
            self.coinpic = Label(self.frame1, image = Coin, bg = 'black', height = 50, width = 50)
            self.coinpic.pack(side = 'left')
            self.coincounter = Label(self.frame1, text = self.coins, foreground = 'white', bg = 'black', justify = 'left')
            self.coincounter.pack(side = 'left')

        elif self.collisionbad1 == False:
            self.bad1 = self.canvasO.create_oval(self.badx1 - 6, self.bady1 - 6, self.badx1 + 6, self.bady1 + 6, fill = 'yellow')


        if (self.x <= self.badx2 + 16 and self.x >= self.badx2 - 16 and self.y <= self.bady2 + 16 and self.y >= self.bady2 - 16) and self.collisionbad2 == False:
            self.canvasO.delete(self.bad2)
            self.collisionbad2 = True
            self.hearts -= 1
            self.heartcounter.destroy()
            self.heartcounter = Label(self.frame1, text = self.hearts, foreground = 'white', bg = 'black', justify = 'left')
            self.heartcounter.pack(side = 'left')
            self.coinpic.destroy()
            self.coincounter.destroy()
            self.coinpic = Label(self.frame1, image = Coin, bg = 'black', height = 50, width = 50)
            self.coinpic.pack(side = 'left')
            self.coincounter = Label(self.frame1, text = self.coins, foreground = 'white', bg = 'black', justify = 'left')
            self.coincounter.pack(side = 'left')

        elif self.collisionbad2 == False:
            self.bad2 = self.canvasO.create_oval(self.badx2 - 6, self.bady2 - 6, self.badx2 + 6, self.bady2 + 6, fill = 'yellow')


        if (self.x <= self.badx3 + 16 and self.x >= self.badx3 - 16 and self.y <= self.bady3 + 16 and self.y >= self.bady3 - 16) and self.collisionbad3 == False:
            self.canvasO.delete(self.bad3)
            self.collisionbad3 = True
            self.hearts -= 1
            self.heartcounter.destroy()
            self.heartcounter = Label(self.frame1, text = self.hearts, foreground = 'white', bg = 'black', justify = 'left')
            self.heartcounter.pack(side = 'left')
            self.coinpic.destroy()
            self.coincounter.destroy()
            self.coinpic = Label(self.frame1, image = Coin, bg = 'black', height = 50, width = 50)
            self.coinpic.pack(side = 'left')
            self.coincounter = Label(self.frame1, text = self.coins, foreground = 'white', bg = 'black', justify = 'left')
            self.coincounter.pack(side = 'left')

        elif self.collisionbad3 == False:
            self.bad3 = self.canvasO.create_oval(self.badx3 - 6, self.bady3 - 6, self.badx3 + 6, self.bady3 + 6, fill = 'yellow')

        #it checks for collision with the heart and changes the heartcounter accordingly
        if self.x >= self.heartlocation[0] - 20 and self.x <= self.heartlocation[0] + 20 and self.y >= self.heartlocation[1] - 20 and self.y <= self.heartlocation[1] + 20 and self.heartcollision == False:
            self.heartcollision = True
            self.canvasO.delete(self.heart)
            self.hearts += 1
            self.heartcounter.destroy()
            self.heartcounter = Label(self.frame1, text = self.hearts, foreground = 'white', bg = 'black', justify = 'left')
            self.heartcounter.pack(side = 'left')
            self.coinpic.destroy()
            self.coincounter.destroy()
            self.coinpic = Label(self.frame1, image = Coin, bg = 'black', height = 50, width = 50)
            self.coinpic.pack(side = 'left')
            self.coincounter = Label(self.frame1, text = self.coins, foreground = 'white', bg = 'black', justify = 'left')
            self.coincounter.pack(side = 'left')

        elif self.heartcollision == False:
            self.heart = self.canvasO.create_image(self.heartlocation[0], self.heartlocation[1], image = Heart)

        #it checks for collision with the coin and changes the coincounter accordingly
        if self.x >= self.coinlocation[0] - 20 and self.x <= self.coinlocation[0] + 20 and self.y >= self.coinlocation[1] - 20 and self.y <= self.coinlocation[1] + 20 and self.coincollision == False:
            self.coincollision = True
            self.canvasO.delete(self.coin)
            self.coins += 1
            self.coincounter.destroy()
            self.coincounter = Label(self.frame1, text = self.coins, foreground = 'white', bg = 'black', justify = 'left')
            self.coincounter.pack(side = 'left')

        elif self.coincollision == False:
            self.coin = self.canvasO.create_image(self.coinlocation[0], self.coinlocation[1], image = Coin)

        #checks if player is done with levels and is in the winning area
        if (self.x < 516 and self.x > 490 and self.y < 492 and self.y > 470) and self.levelsleft == 1:
            self.canvasO.delete(ALL)
            self.message = self.canvasO.create_text(350, 325, text = 'Congratulations!\n YOU WON!', justify = CENTER, fill = 'white', font = 40)
            self.backbutton = self.canvasO.create_rectangle(560, 600, 625, 625, fill = 'white')
            self.buttontxt = self.canvasO.create_text(595, 610, text = 'Done')

            #checks if the user has a highscore
            f = open('highscore.txt', 'r')
            content = f.readline()

            if (content == '' and self.gameover == False):
                self.gameover = True
                self.w = Toplevel()
                self.HSmessage = Label(self.w, text = 'Congratulations! You got the highscore. \n Please enter your username:')
                self.HSmessage.pack()
                self.user = Entry(self.w)
                self.but = Button(self.w, text = 'enter', command = self.saveHS)
                self.user.pack()
                self.but.pack()
                f.close()

            elif (int(content[-1]) <= self.coins and self.gameover == False):
                self.gameover = True
                self.w = Toplevel()
                self.HSmessage = Label(self.w, text = 'Congratulations! You got the highscore. \n Please enter your username:')
                self.HSmessage.pack()
                self.user = Entry(self.w)
                self.but = Button(self.w, text = 'enter', command = self.saveHS)
                self.user.pack()
                self.but.pack()
                f.close()
            
                                       
        #if the player has levels left to complete, he is gven 3 option, save game, keep playing and quit    
        elif (self.x < 516 and self.x > 490 and self.y < 492 and self.y > 470) and self.levelsleft != 1:
            self.canvasO.delete(ALL)
            self.message = self.canvasO.create_text(350, 325, text = 'Would you like to continue\n or to save the game?', justify = CENTER, fill = 'white', font = 40)
            self.quitbutton = self.canvasO.create_rectangle(560, 600, 625, 625, fill = 'white')
            self.buttontxt1 = self.canvasO.create_text(595, 610, text = 'quit')
            self.playbutton = self.canvasO.create_rectangle(560, 550, 625, 575, fill = 'white')
            self.buttontxt2 = self.canvasO.create_text(595, 560, text = 'play')
            self.savebutton = self.canvasO.create_rectangle(560, 500, 625, 525, fill = 'white')
            self.buttontxt3 = self.canvasO.create_text(595, 510, text = 'save')            

        #if the player reaches 0 hearts then he loses
        if self.hearts == 0:
            self.canvasO.delete(ALL)
            self.heartcollision = True
            self.coincollision = True
            self.collisionbad1 = True
            self.collisionbad2 = True
            self.collisionnad3 = True
            self.message = self.canvasO.create_text(350, 325, text = 'YOU LOSE', justify = CENTER, fill = 'white', font = 40)
            self.backbutton = self.canvasO.create_rectangle(560, 600, 625, 625, fill = 'white')
            self.buttontxt = self.canvasO.create_text(595, 610, text = 'Done')


        
    def redraw2(self):
        #this function checks for win of players and moves the characters according to the change of their coordinates
        self.canvasO1.delete(self.player1)
        self.player1 = self.canvasO1.create_oval(self.x1 - 10, self.y1 - 10, self.x1 + 10, self.y1 + 10, fill = 'blue', outline = 'blue')
        self.canvasO1.delete(self.player2)
        self.player2 = self.canvasO1.create_oval(self.x2 - 10, self.y2 - 10, self.x2 + 10, self.y2 + 10, fill = 'red', outline = 'red')

        if (self.x1 < 516 and self.x1 > 481 and self.y1 < 492 and self.y1 > 442):
            self.canvasO1.delete(ALL)
            self.message1 = self.canvasO1.create_text(700, 325, text = 'Congratulations Player 1!\n YOU WON!', justify = CENTER, fill = 'white', font = 40)
            self.backbutton = self.canvasO1.create_rectangle(560, 600, 625, 625, fill = 'white')
            self.buttontxt1 = self.canvasO1.create_text(595, 610, text = 'Done')

        if (self.x2 < 1216 and self.x2 > 1181 and self.y2 < 492 and self.y2 > 442):
            self.canvasO1.delete(ALL)
            self.message = self.canvasO1.create_text(700, 325, text = 'Congratulations Player 2!\n YOU WON!', justify = CENTER, fill = 'white', font = 40)
            self.backbutton = self.canvasO1.create_rectangle(560, 600, 625, 625, fill = 'white') 
            self.buttontxt1 = self.canvasO1.create_text(595, 610, text = 'Done')



    def timer1(self):
        #this function checks validity of move and changes speed of the character based on the keypressed.
        #1 player
        if self.y + 1 >= 162:
            if self.theMaze.get(self.x - 172, self.y - 11 - 146) == '255 255 255':
                self.y += self.velocities[0]
        if self.y + 1 <= 492:
            if self.theMaze.get(self.x - 172, self.y + 11 - 146) == '255 255 255':
                self.y += self.velocities[1]
        if self.x + 1 <= 516:
            if self.theMaze.get(self.x + 11 - 169, self.y - 146) == '255 255 255':
                self.x += self.velocities[2]
        if self.x + 1 >= 185:
            if self.theMaze.get(self.x - 11 - 171, self.y - 146) == '255 255 255':
                self.x += self.velocities[3]        

        self.MoveBaddie()
        self.redraw1()
        self.frame1.after(5, self.timer1)

    def timer2(self):
        #this function checks validity of move and changes speed of the character based on the keypressed.
        #2 player
        if self.y1 + 1 >= 162:
            if self.FirstMaze.get(self.x1 - 172, self.y1 - 11 - 146) == '255 255 255':
                self.y1 += self.velocities1[0]
                
        if self.y1 + 1 <= 492:
            if self.FirstMaze.get(self.x1 - 172, self.y1 + 11 - 146) == '255 255 255':
                self.y1 += self.velocities1[1]

        if self.x1 + 1 <= 516:
            if self.FirstMaze.get(self.x1 + 11 - 169, self.y1 - 146) == '255 255 255':
                self.x1 += self.velocities1[2]
                
        if self.x1 + 1 >= 185:
            if self.FirstMaze.get(self.x1 - 11 - 171, self.y1 - 146) == '255 255 255':
                self.x1 += self.velocities1[3]


        if self.y2 + 1 >= 162:
            if self.SecondMaze.get(self.x2 - 872, self.y2 - 11 - 146) == '255 255 255':
                self.y2 += self.velocities2[0]
                
        if self.y2 + 1 <= 492:       
            if self.SecondMaze.get(self.x2 - 872, self.y2 + 11 - 146) == '255 255 255':
                self.y2 += self.velocities2[1]

        if self.x2 + 1 <= 1216:
            if self.SecondMaze.get(self.x2 + 11 - 869, self.y2 - 146) == '255 255 255':
                self.x2 += self.velocities2[2]
                
        if self.x2 + 1 >= 885:
            if self.SecondMaze.get(self.x2 - 11 - 871, self.y2 - 146) == '255 255 255':
                self.x2 += self.velocities2[3]

        self.redraw2()
        self.frame1.after(5, self.timer2)

    def mousepressed(self, event):
        #this function is called when the mouse is pressed on one of the screens in the maze (1 player in between levels screen
        #and 2 player end screen)
        if (event.x >= 560 and event.x <= 625 and event.y >= 600 and event.y <= 625):
            self.window.destroy()

        elif (event.x >= 560 and event.x <= 625 and event.y >= 525 and event.y <= 575):
            self.window.destroy()
            Maze(self.parentM, 1, mazes, self.levelsleft - 1, self.hearts, self.coins)

        #saves needed info for saved game
        elif (event.x >= 560 and event.x <= 625 and event.y >= 500 and event.y <= 525):
            f = open('levels.txt', 'w')
            f.write(str(self.levelsleft - 1) + '\n')
            f.write(str(self.hearts) + '\n')
            f.write(str(self.coins) + '\n')
            f.close()
            self.window.destroy()

    def saveHS(self):
        #function called for username entry
        self.UsernameHS = self.user.get()
        f = open('highscore.txt', 'w')
        f.write(self.UsernameHS + ' ' + str(self.coins))
        self.w.destroy()
        self.window.destroy()


wnd = Tk()

Maze1 = PhotoImage(file = 'maze1.gif')
Maze2 = PhotoImage(file = 'maze2.gif')
mazes = [Maze1, Maze2]

homePageBg = PhotoImage(file = 'MAZE.gif')
InstructionsPage = PhotoImage(file = 'InstructionsPage.gif')
Scoreboardpage = PhotoImage(file = 'Scoreboard.gif')
Heart = PhotoImage(file = 'heart.gif')
Coin = PhotoImage(file = 'coin.gif')

wnd.geometry('700x700')
wnd.resizable(width = False, height = False)
game = HomePage(wnd, mazes)
wnd.mainloop()
